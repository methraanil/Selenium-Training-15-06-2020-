function myFunction(b) {
  var a = document.getElementById(b).getAttribute('value');  
  a=parseInt(a);
  a=a+1;
  document.getElementById(b).innerHTML=a;
  document.getElementById(b).setAttribute("value",a);  
}
function sub(b){
  var a = document.getElementById(b).getAttribute('value');   
  a=parseInt(a);
	if(a>0){
    a=a-1;
  document.getElementById(b).innerHTML=a;
  document.getElementById(b).setAttribute("value",a);  
  }

}
function orderFunction() {
	  var x = document.getElementById("myDIV");
	  if (x.style.display === "none") {
	    x.style.display = "block";
	  } else {
	    x.style.display = "none";
	  }
	}